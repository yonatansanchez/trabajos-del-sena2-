// auth.js
// Este script comprueba si el usuario ha iniciado sesión.
// Si no lo ha hecho, lo redirige a la página de login.
if (sessionStorage.getItem('isAdminAuthenticated') !== 'true') {
    alert('Acceso denegado. Debes iniciar sesión como administrador.');
    window.location.href = 'login.html';
}